# SEG2105-Olympus
SEG2105 final project, Ivana Erlich, Anshu Sharma, Batuhan Basoglu, Mary Tran

https://github.com/ebivibe/SEG2105-Olympus

Build Status 
[![CircleCI](https://circleci.com/gh/ebivibe/SEG2105-Olympus/tree/master.svg?style=svg&circle-token=01dbbc3800d7ee80871796675582a67ba7c83604)](https://circleci.com/gh/ebivibe/SEG2105-Olympus/tree/master)

APK tested on a Sony Xperia XA2, model H3123

Admin account is precreated with username = admin, password = admin


3 ServiceProvider accounts are precreated with 
username = testing, password = testing;
username = testing1, password = testing;
username = testing2, password = testing. 
Service providers are available for the entire day if they are available. 
There is at least one service provider available on any day.


3 HomeOwner accounts are precreated with 
username = tester, password = tester;
username = tester1, password = tester;
username = tester2, password = tester


10 services are precreated. 
All three service providers offer the Dragon Tamer service.
No service provider offers the Maid or Butler services.
At least one service provider offers the remaining services.


10 bookings are precreated.
All three service providers have been booked with the Dragon Tamer service.
Only two home owners (tester and tester1) have made bookings.

THERE BE DRAGONS

